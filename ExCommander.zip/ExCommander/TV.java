public class TV {
    public void ligar() {
        System.out.println("TV ligada.");
    }

    public void desligar() {
        System.out.println("TV desligada.");
    }
}
