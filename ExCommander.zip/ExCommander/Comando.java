public interface Comando {
    void executar();
    void desfazer();
}
