public class FabricaDeInimigosGelo implements FabricaDeInimigos {
  public Guerreiro criarGuerreiro(){
    return new GuerreiroDeGelo();
  }
  public Mago criarMago(){
    return new MagoDeGelo();
  }
}