public interface Guerreiro {
  public void atacar();
}