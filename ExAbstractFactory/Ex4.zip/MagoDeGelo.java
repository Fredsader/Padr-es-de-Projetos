public class MagoDeGelo implements Mago {
  public void soltarMagia(){
    System.out.println("Estaca de gelo...");
  }
}