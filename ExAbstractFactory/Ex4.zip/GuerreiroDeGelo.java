public class GuerreiroDeGelo implements Guerreiro{
  public void atacar(){
    System.out.println("Ataque com adagas");
  }
}