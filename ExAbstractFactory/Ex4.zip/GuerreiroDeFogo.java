public class GuerreiroDeFogo implements Guerreiro{
  @Override
  public void atacar(){
    System.out.println("Ataque com espada longa...");
  }
}