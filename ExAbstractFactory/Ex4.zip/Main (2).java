import java.util.*;

public class Main {
    public static void main(String[] args) {
      FabricaDeInimigos fabricaGuerreirosFogo = new FabricaDeInimigosFogo();
      FabricaDeInimigos fabricaMagosFogo = new FabricaDeInimigosFogo();
      FabricaDeInimigos fabricaGuerreirosGelo = new FabricaDeInimigosGelo();
      FabricaDeInimigos fabricaMagosGelo = new FabricaDeInimigosGelo();
      
      Guerreiro guerreiroFogo = fabricaGuerreirosFogo.criarGuerreiro();
      Guerreiro guerreiroGelo = fabricaGuerreirosGelo.criarGuerreiro();
      Mago magoFogo = fabricaMagosFogo.criarMago();
      Mago magoGelo = fabricaMagosGelo.criarMago();
      
      guerreiroFogo.atacar();
      guerreiroGelo.atacar();
      
      magoFogo.soltarMagia();
      magoGelo.soltarMagia();
  }
}