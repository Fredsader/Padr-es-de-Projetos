public interface FabricaDeInimigos {
  Guerreiro criarGuerreiro();
  Mago criarMago();
}