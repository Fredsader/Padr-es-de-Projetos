public class MagoDeFogo implements Mago {
  public void soltarMagia(){
    System.out.println("Bola de Fogo");
  }
}