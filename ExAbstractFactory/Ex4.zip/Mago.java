public interface Mago {
  public void soltarMagia();
}