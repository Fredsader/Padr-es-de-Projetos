public class FabricaDeInimigosFogo implements FabricaDeInimigos {
  public Guerreiro criarGuerreiro(){
    return new GuerreiroDeFogo();
  }
  public Mago criarMago(){
    return new MagoDeFogo();
  }
}