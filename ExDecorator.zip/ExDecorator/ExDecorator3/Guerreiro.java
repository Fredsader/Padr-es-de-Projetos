class Guerreiro implements Personagem {
    public String getDescricao() {
        return "Guerreiro";
    }
    
    public int getDefesaTotal() {
        return 10;
    }
} 