interface Personagem {
    String getDescricao();
    int getDefesaTotal();
} 