public interface Texto {
    String formata();
    int getTotalCaracteres();
} 