public interface Bebida {
    String getDescricao();
    double getPreco();
} 