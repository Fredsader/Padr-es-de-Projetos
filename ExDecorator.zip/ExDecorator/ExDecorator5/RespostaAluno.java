class RespostaAluno implements Resposta {
    private String texto;
    
    public RespostaAluno(String texto) {
        this.texto = texto;
    }
    
    public int getNotaFinal() {
        return 0;
    }
} 