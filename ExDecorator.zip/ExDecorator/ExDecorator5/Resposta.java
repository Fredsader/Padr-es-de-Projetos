interface Resposta {
    int getNotaFinal();
} 