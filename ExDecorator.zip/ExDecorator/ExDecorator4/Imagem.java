interface Imagem {
    void imprimir();
} 