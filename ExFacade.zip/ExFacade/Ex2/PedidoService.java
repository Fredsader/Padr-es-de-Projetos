public class PedidoService {
    public void registrar() {
        System.out.println("Pedido registrado.");
    }
}
