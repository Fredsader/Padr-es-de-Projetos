public class FreteService {
    public void calcular() {
        System.out.println("Frete calculado.");
    }
}
