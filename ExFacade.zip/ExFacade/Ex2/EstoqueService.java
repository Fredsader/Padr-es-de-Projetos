public class EstoqueService {
    public void verificar() {
        System.out.println("Estoque verificado.");
    }
}
