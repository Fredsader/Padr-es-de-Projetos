public class EmailService {
    public void enviarConfirmacao() {
        System.out.println("Confirmação de pedido enviada por e-mail.");
    }
}
