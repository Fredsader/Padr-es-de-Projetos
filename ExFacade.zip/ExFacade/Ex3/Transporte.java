public class Transporte {
    public void agendar() {
        System.out.println("Transporte agendado.");
    }
}
