public class SeguroViagem {
    public void comprar() {
        System.out.println("Seguro de viagem comprado.");
    }
}
