public class ReservaHotel {
    public void reservar() {
        System.out.println("Hotel reservado.");
    }
}
