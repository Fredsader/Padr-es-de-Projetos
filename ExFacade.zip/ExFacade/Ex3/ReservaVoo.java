public class ReservaVoo {
    public void reservar() {
        System.out.println("Voo reservado.");
    }
}
