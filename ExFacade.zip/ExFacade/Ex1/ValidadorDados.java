public class ValidadorDados {
    public void validar() {
        System.out.println("Dados do estudante validados.");
    }
}
