public class CartaoEstudante {
    public void gerarCartao() {
        System.out.println("Cartão de estudante gerado.");
    }
}
