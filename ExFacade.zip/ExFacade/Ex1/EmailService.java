public class EmailService {
    public void enviarBoasVindas() {
        System.out.println("E-mail de boas-vindas enviado.");
    }
}
